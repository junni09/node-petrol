var express = require("express");
var router = express.Router();
var mysql = require('mysql');
var passport = require('passport');
var LocalStrategy  = require('passport-local').Strategy;
var yourGlobalVariable = 0;

// connection string MYSQL
var con = mysql.createConnection({
host: "localhost",
user: "root",
password: "junaid123",
database: "project"
});
// connection string MYSQL


var loggedin = function (req, res, next) {
  if (req.isAuthenticated()) {
    next();
  }
  else {
    res.redirect('/')
  }
};

var loggedin1 = function (req, res, next) {
  if (req.isAuthenticated()) {
    res.redirect('/client');
  }
  else {
    next();
  }
};

var Adminloggedin = function (req, res, next) {
  if (req.isAuthenticated()) {
    next();
  }
  else {
    res.redirect('/admin')
  }
};

var Adminloggedin1 = function (req, res, next) {
  if (req.isAuthenticated()) {
    res.redirect('/dashboard');
  }
  else {
    next();
  }
};


router.post("/client", passport.authenticate('local', {

    successRedirect: '/client',
    failureRedirect: '/auts',
    failureFlash: true
}), function(req, res, info){

    res.render('login/index',{'message' :req.flash('message')});

});


//client services
router.get('/',loggedin1,function(req,res)  // Route for index page
{
  res.header('Cache-Control', 'no-cache, private, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0');
  console.log("in /");
        res.render("index");
});


router.get('/client',loggedin,function(req,res) // route for login client page
{
  res.header('Cache-Control', 'no-cache, private, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0');

      console.log("in /client");
      console.log("true id");
      console.log("Authenticate");   // checking login or not

    clientID  =req.session.passport.user.PK_Client;
    stationID =req.session.passport.user.PK_Station;

    console.log("clientID :"+clientID);
    console.log("StationID :"+stationID);
    console.log("alert in client");
    // query for getting all data

  

try {
    con.query("select   sum(data.transactions * data.DataRate ) as price ,sum(data.transactions) as liter , client.UserName, client.Caddress ,client.Age, fueltype.FuelType ,fueltype.PK_FuelType,pump.PK_Pump ,pump.device_id, pump.Pname ,station.Name  ,client.Cname ,station.Contact,client.Ccontact  ,station.NoOfPumps  from client inner join station on client.PK_Client = station.FK_Client inner join pump on pump.FK_Station = station.PK_Station left join data on pump.PK_Pump = data.FK_Pump inner join fueltype on fueltype.PK_FuelType = pump.FuelType where PK_Client = ? and station.PK_Station = ? group by pump.device_id ;",[clientID,stationID] ,function (err, result) {
    if (err)
    {
       throw err;
    }
    console.log(result);
    res.render("client" , {client: result});
  });
}
catch(err) {
    res.redirect("/notfound");
}

});


router.get('/pump/:id',loggedin,function(req,res)  // Route for index page
{
  res.header('Cache-Control', 'no-cache, private, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0');
  var clientID = req.session.passport.user.PK_Client ;
  var stationID = req.session.passport.user.PK_Station;

  console.log(clientID);
  console.log(stationID);
  var pump = req.params.id;
  console.log(pump);

      console.log("alert in pump")
  con.query("select  (data.transactions * data.DataRate ) as price , pump.Rate,client.Cname, station.Name, data.transactions , pump.Fueltype,data.DataTime ,pump.device_id, pump.Pname  from client inner join station on client.PK_Client = station.FK_Client inner join pump on pump.FK_Station = station.PK_Station left join data on pump.PK_Pump = data.FK_Pump  where PK_Client = ? and station.PK_Station = ? and pump.PK_Pump= ?",[clientID,stationID,pump] ,function (err, result) {

  if (err)
  {
     throw err;
  }
  console.log(result);
  res.render("pump" , {pump: result});
});
});


router.get('/Logout', function(req, res){
  console.log('/Logout');
  req.logout();
  res.redirect('/');
});

router.get('/AdminLogout', function(req, res){
  console.log('/admin Logout');
  req.logout();
  res.redirect('/admin');
});


router.get('/auts',function(req,res)  // Route for index page{
  {
    res.header('Cache-Control', 'no-cache, private, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0');
      res.render('auts');
});




/////////////////////////////////////////////////////////




router.post("/dashboard", passport.authenticate('localadmin', {

    successRedirect: '/dashboard',
    failureRedirect: '/adminauts',
    failureFlash: true
}), function(req, res, info){

    res.render('login/index',{'message' :req.flash('message')});

});

router.get('/admin',Adminloggedin1,function(req,res)  // Route for Admin index page
  {
    res.header('Cache-Control', 'no-cache, private, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0');
       res.render('admin');
});


router.get('/dashboard',Adminloggedin,function(req,res)
  {

    res.header('Cache-Control', 'no-cache, private, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0');
    console.log(" in dashboard");
           // showing data LogoutLogout
console.log("Dashboard: "+req.session.passport.user );
console.log("true admin id");
console.log("admin Authenticate");   // checking login or not


// query for getting all data
con.query("select adminn.AdminName , client.Deleted , client.PK_Client ,client.Cname , station.PK_Station , station.Name from adminn , client inner join station on client.PK_Client = station.FK_Client where adminn.PK_Admin = ? ; ",[req.session.passport.user.PK_Admin],function (err, result) {

if (err)
{
   throw err;
}
console.log(result);
yourGlobalVariable = 0
res.render('dashboard', {board: result});
});

});


router.get('/station/:id1/:id2',Adminloggedin,function(req,res) // route for login client page
{
    res.header('Cache-Control', 'no-cache, private, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0');
    console.log("in /station");


  var station = req.params.id1;
  var client = req.params.id2;

  con.query("select  client.PK_Client , station.PK_Station , sum(data.transactions * data.DataRate ) as price , sum(data.transactions) as liter , client.UserName ,client.Caddress ,client.Age, fueltype.FuelType ,fueltype.PK_FuelType,pump.PK_Pump ,pump.device_id, pump.Pname ,station.Name  ,client.Cname ,station.Contact,client.Ccontact  ,station.NoOfPumps  from client inner join station on client.PK_Client = station.FK_Client inner join pump on pump.FK_Station = station.PK_Station left join data on pump.PK_Pump = data.FK_Pump inner join fueltype on fueltype.PK_FuelType = pump.FuelType where PK_Client = ? and station.PK_Station = ? group by pump.device_id ;",[client,station] ,function (err, result) {

  if (err)
  {
     throw err;
  }
  console.log(result);
  res.render("station" , {client: result});
});
  });


  router.get('/adminpump/:id/:id1/:id2',Adminloggedin,function(req,res)  // Route for index page
  {

    res.header('Cache-Control', 'no-cache, private, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0');

    var pump = req.params.id;
    var stationID  = req.params.id1
    var clientID =  req.params.id2
    console.log(pump);
    con.query("select  (data.transactions * data.DataRate) as price , data.DataRate,client.Cname, station.Name, data.transactions , pump.Fueltype,data.DataTime ,pump.device_id, pump.Pname , pump.Rate from client inner join station on client.PK_Client = station.FK_Client inner join pump on pump.FK_Station = station.PK_Station left join data on pump.PK_Pump = data.FK_Pump  where PK_Client = ? and station.PK_Station = ? and pump.PK_Pump= ?",[clientID,stationID,pump] ,function (err, result) {

    if (err)
    {
       throw err;
    }
    console.log(result);
    res.render("adminpump" , {pump: result});
  });
  });


//admin services

  router.get('/addclient',Adminloggedin,function(req,res)
    {
      res.header('Cache-Control', 'no-cache, private, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0');
      console.log(" in addclient");
      console.log("yourGlobalVariable: "+ yourGlobalVariable);
      if(yourGlobalVariable == 0){
        console.log("if 0 yourGlobalVariable: "+ yourGlobalVariable);
      var object = {
        'message' : ''
      };
    res.render('addclient',{obj : object});
  }
  if(yourGlobalVariable == 1){
  console.log("if 1 yourGlobalVariable: "+ yourGlobalVariable);
  var object = {
    'message' : 'username name already already exist'
  };
res.render('addclient',{obj : object});
}
if(yourGlobalVariable == 2){
console.log("if 1 yourGlobalVariable: "+ yourGlobalVariable);
var object = {
  'message' : 'device id already already exist'
};
res.render('addclient',{obj : object});
}
    });

    router.get('/editclient',Adminloggedin,function(req,res)
      {
        res.header('Cache-Control', 'no-cache, private, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0');
        console.log(" in editclient");


        con.query("select adminn.AdminName , client.Deleted , client.PK_Client ,client.Cname , station.PK_Station , station.Name from adminn , client inner join station on client.PK_Client = station.FK_Client where adminn.PK_Admin = ? ; ",[req.session.passport.user.PK_Admin],function (err, result) {

        if (err)
        {
           throw err;
        }
        console.log(result);

        res.render('editclient', {board: result});
        });

      });

      router.get('/deleteclient',Adminloggedin,function(req,res)
        {
          res.header('Cache-Control', 'no-cache, private, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0');
          console.log(" in deleteclient");


          con.query("select adminn.AdminName , client.Deleted , client.PK_Client ,client.Cname , station.PK_Station , station.Name from adminn , client inner join station on client.PK_Client = station.FK_Client where adminn.PK_Admin = ? ; ",[req.session.passport.user.PK_Admin],function (err, result) {

          if (err)
          {
             throw err;
          }
          console.log(result);

          res.render('deleteclient', {board: result});
          });

        });

        router.get('/dashboard/:id',Adminloggedin,function(req,res)
          {
            res.header('Cache-Control', 'no-cache, private, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0');
            console.log(" in deleteclient");
                var client = req.params.id ;
            console.log("id :"+client);

          con.query("update client set Deleted = 1  where PK_Client = ? ; " ,[client],function (err, result) {

            if (err)
            {
               throw err;
            }
            console.log(result);
            res.redirect('/dashboard')

          });

          });

      router.get('/editclientform/:id',Adminloggedin,function(req,res)
        {
          res.header('Cache-Control', 'no-cache, private, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0');
          console.log(" in editclientform");


          var client = req.params.id ;
          con.query("select adminn.AdminName  , client.PK_Client ,client.Cname , client.UserName , client.Age ,  client.Ccontact ,client.Caddress  from adminn , client  where adminn.PK_Admin = ? and client.PK_Client = ? ; ",[req.session.passport.user.PK_Admin,client],function (err, result) {

          if (err)
          {
             throw err;
          }
          console.log(result);

          res.render('editclientform', {board: result});
        });

        });

        router.post('/editdone',Adminloggedin,function(req,res)
          {
            res.header('Cache-Control', 'no-cache, private, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0');
            console.log(" in editdone");


            con.query("update client set Cname = ? ,  Age = ? , Ccontact = ? , Caddress=? where PK_Client = ? ; ",[req.body.name, req.body.age ,req.body.contact ,req.body.address , req.body.id],function (err, result) {



            res.redirect('/dashboard');
            });

          });


    router.post('/signup',function(req,res)
    {
          res.header('Cache-Control', 'no-cache, private, no-store, must-revalidate, max-stale=0, post-check=0, pre-check=0');
          console.log(" in signup");

          var ClientName = String(req.body.ClientName)  ;
          var ClientUserName = String(req.body.ClientUserName)  ;
          var ClientPassword = String(req.body.ClientPassword)  ;
          var ClientAge = parseInt(req.body.ClientAge)  ;
          var ClientNumber = parseInt(req.body.ClientNumber)  ;
          var ClientAddress = String(req.body.ClientAddress)  ;
          var StationName = String(req.body.StationName)  ;
          var StationContact = parseInt(req.body.StationContact)  ;
          var StationPump = parseInt(req.body.StationPump)  ;
          var PumpName = String(req.body.PumpName1)  ;


          console.log(ClientName);
          console.log(ClientUserName);
          console.log(ClientPassword);
          console.log(ClientAge);
          console.log(ClientNumber);
          console.log(ClientAddress);
          console.log(PumpName);

          con.query("select  * from client where UserName = ?",[ClientUserName] ,function (checkerr, check)
           {
            console.log("check : " + check);
            if(check.length == 0)
            {
              var count = 1 ;

              function checkIDfunc(exefunc){
                console.log("in checkIDfunc");
                 count = 0 ;
                 var counter = 0 ;
                  console.log("count : "+ count);
                for(var i = 1 ; i <= StationPump ; i++ )
                {

                  console.log("for loop");
                    DeviceIDD = "DeviceID"+i;
                    var DeviceIDD = String(req.body[DeviceIDD])
                  con.query("select * from pump where device_id = ?",[DeviceIDD] ,function (checkIDerr, checkID)
                   {
                     if(checkID.length > 0)
                     {
                      console.log("count++ ");
                       count++ ;
                      console.log("count : "+ count);
                     }
                     counter++ ;
                     if(counter == StationPump )
                     {
                        console.log("counter == StationPump");
                         exefunc(count);
                     }

                   });
                }

              };
              var exefunc1 = function exefunc(count){
                  console.log("count exe : "+ count);
              if(count==0){
                console.log("in exefunc");
                console.log("db if");
                        var sql = "INSERT INTO client (Cname, UserName,Password,Age,Ccontact,Caddress) VALUES (?, ? ,? , ? ,? ,?)";


                        con.query(sql,[ClientName, ClientUserName ,ClientPassword , ClientAge ,ClientNumber ,ClientAddress], function (err, result)
                         {
                          if (err) throw err;
                          console.log("1 record inserted");
                          console.log(result);
                                  con.query("select max(PK_Client) as Ckey from client ", function (Clienterr, ClientKey)
                                   {
                                    if (Clienterr) throw Clienterr;
                                    console.log("Client Key: "+ClientKey[0].Ckey);
                                    var clientkey = ClientKey[0].Ckey ;
                                    console.log("Client Key: "+clientkey);

                                                con.query("INSERT INTO station (FK_Client, Name,Contact,NoOfPumps) VALUES (?, ? ,? ,?)",[clientkey,StationName,StationContact,StationPump], function (error, result33)
                                                 {
                                                  if (error) throw error ;
                                                  console.log("1 record inserted");
                                                  console.log(result33);
                                                  con.query("select max(PK_Station) as Skey from station", function (error22, result22)
                                                   {
                                                    if (error22) throw error22 ;
                                                    console.log(" Station Key: "+result22[0].Skey);
                                                    var stationkey = result22[0].Skey ;
                                                    console.log("Station Key: "+ stationkey);



                                                          for(var i  = 1 ; i <=StationPump ; i++){

                                                               PumpName = "PumpName"+i;
                                                               DeviceID = "DeviceID"+i;
                                                               Rate = "Rate"+i;
                                                               type = "type"+i;

                                                              var PumpName = String(req.body[PumpName])  ;
                                                              var DeviceID = String(req.body[DeviceID])  ;
                                                              var FuelType = parseInt(req.body[type]) ;
                                                              var Rate = parseInt(req.body[Rate]) ;

                                                              console.log("PumpName :"+PumpName);
                                                              console.log("DeviceID :"+DeviceID);
                                                              console.log("FuelType :"+FuelType);
                                                              console.log("Rate :"+Rate);
                                                                con.query("INSERT INTO pump (FK_Station, Pname,device_id,Fueltype,Rate) VALUES (?,?,?,?,?)",[stationkey,PumpName,DeviceID,FuelType,Rate], function (error333, result333)
                                                                 {
                                                                  if (error333) throw error333 ;
                                                                  console.log("1 record inserted");
                                                                  console.log(result333);

                                                                });
                                                              }
                                                    });

                                                });
                                  });
                        });
                        res.redirect('/dashboard');
                      }
                      else {
                        console.log("ele exefunc");
                        yourGlobalVariable = 2 ;
                        res.redirect('/addclient')

                      }
                    }

                    checkIDfunc(exefunc1);

            }
            else {
              console.log("db else");
                yourGlobalVariable = 1 ;

              res.redirect('/addclient')
            }
            });
        });


router.get('/adminAuts',function(req,res)  // Route for index page{
  {
       res.render('adminauts');

});


router.get('/notfound', function(req, res){
  console.log('in notfound');
   res.render('notfound');
});


router.get('*', function(req, res){
  console.log('*');
   res.redirect('/notfound');
});








module.exports = router ;
