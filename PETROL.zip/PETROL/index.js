var express = require("express");
var app = express();
var bodyParser = require("body-parser");
var session = require('express-session');
var Store   = require('express-session').Store;
var passport = require('passport');
var LocalStrategy  = require('passport-local').Strategy;
var connection  = require('./lib/dbconn');
var flash = require('connect-flash');
var crypto  = require('crypto');
var mysql = require('mysql');
var BetterMemoryStore = require('session-memory-store')(session);

var port = process.env.PORT || 3000 ;

var routes = require('./routes/route.js');



app.set("view engine" , "ejs");

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended:true}));

var store = new BetterMemoryStore({ expires: 60 * 60 * 1000, debug: true });

 app.use(session({

    name: 'JSESSION',

    secret: 'MYSECRETISVERYSECRET',

    store:  store,

    resave: true,

    saveUninitialized: true

}));
app.use(flash());

app.use(passport.initialize());

app.use(passport.session());
app.use(function(req, res, next) {
  res.locals.user = req.session.user;
  next();
});

passport.use('local', new LocalStrategy({

  usernameField: 'Username',

  passwordField: 'password',

  passReqToCallback: true //passback entire req to call back
} , function (req, Username, password, done){

      connection.query("select station.PK_Station ,PK_Client from client inner join station on client.PK_Client = station.FK_Client where client.UserName = ? and client.Password = ? and client.Deleted = 0 ",[ Username,password ], function(err, rows){

          console.log(err); console.log(rows);

        if (err) return done(req.flash('message',err));

        if(!rows.length){ return done(null, false, req.flash('message','Invalid username or password.')); }


        return done(null, rows[0]);

      });

    }

));

passport.use('localadmin', new LocalStrategy({

  usernameField: 'adminName',

  passwordField: 'adminPassword',

  passReqToCallback: true //passback entire req to call back
} , function (req, adminName, adminPassword, done){

      connection.query("select PK_Admin from adminn where AdminName = ? and AdminPassword = ? ",[adminName,adminPassword ], function(err, rows){

          console.log(err); console.log(rows);

        if (err) return done(req.flash('message',err));

        if(!rows.length){ return done(null, false, req.flash('message','Invalid username or password.')); }


        return done(null, rows[0]);

      });

    }

));



passport.serializeUser(function(user, done){
    console.log("in serializeUser ");
    done(null, user);

});

passport.deserializeUser(function(user, done){
  console.log("in deserializeUser ");
  var PK_Client = user.PK_Client;
  console.log("PK_Client :::"+ PK_Client );
  if(PK_Client == undefined){
    var PK_Admin = user.PK_Admin;
      console.log("in if" );
    console.log("PK_Admin :::"+ PK_Admin );
    connection.query("select * from adminn where PK_Admin = "+ PK_Admin , function (err, client){
      done(err, client[0]);
  });
}
  else {
      console.log("in else " );
    var PK_Client = user.PK_Client;
    connection.query("select * from client where PK_Client = "+ PK_Client, function (err, admin){
      done(err, admin[0]);
  });

    };

});

app.use(routes);

app.listen(port, function(){

  console.log("listening 3000");


});
